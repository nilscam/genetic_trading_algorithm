usage: ./main.py [CLOCK NB_INDEX]

CLOCK: duration between 2 index (value in second) - default value 0.5 second
NB_INDEX: number of index pushed for each marketplace (int value) - default value 360 indexes

Indexes are written on standard output AND in a ./.index.db file