#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from Manager import Manager

def main():
    m = Manager()

if (__name__ == '__main__'):
    main()
