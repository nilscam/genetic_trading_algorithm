usage: ./main.py

For example, you can run ./push_index/main.py in a terminal AND ./test_client/main.py (or your program) | ./server/main.py in another terminal.

Terminal 1 : cd push_index ; ./main.py
Terminal 2 : cd test_client ; ./main.py | ../server/main.py

On each requests the file ./server/.server.log is updated with user datas (number of shares, current money, ...)